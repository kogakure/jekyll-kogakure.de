==================================
 Iga Ninja Font � Cipher from Iga
==================================

The Iga-Ninja Font was created by Stefan Imhoff (http://stefanimhoff.de) of an image provided by the Iga Ninja Museum in Japan and is said to be a font for correspondence in cipher. It can be downloaded on http://kogakure.de.

----------
 Contents
----------

This package contains two fonts (OTF/TTF), one image with a translation and this README.txt file.

----------
 The Font
----------

The original font was only written in Katakana and was missing modern characters (the one with " or �). I added these, plus the smaller version of some Kana. The font is available as Katakana and Hiragana. One character, which is not used any more but was in the past, I added to the "0".

---------
 Licence
---------

This font is provided under a licence of Creative Commons Attribution-NonCommercial 3.0 Unported (CC BY-NC 3.0): http://creativecommons.org/licenses/by-nc/3.0/deed

